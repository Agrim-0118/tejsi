export default function Home() {
  return (
    <div className="h-screen w-screen bg-gradient-to-r from-green-600 via-green-400 to-lime-300 animate-gradient-x flex">

      {/* Left Side: Slogan + Logo + Title + Navigation */}
      <div className="flex-1 flex flex-col justify-center items-center text-white text-center px-8">
        
        {/* Slogan on top */}
        <p className="text-4xl md:text-5xl font-extrabold tracking-wider mb-6 drop-shadow-lg text-yellow-100">
  🌱 Protecting Our Soil, 🌿 Preventing Landslides, 🌞 Combating Desertification! 💚
        </p>

        {/* Logo */}
        <img
          src="/logo.png"
          alt="Eco Alert Logo"
          className="w-[28rem] h-[28rem] drop-shadow-2xl animate-bounce-slow object-contain"
        />

        {/* Title */}
        <h1 className="text-[10rem] font-extrabold drop-shadow-2xl tracking-wide -mt-12">
          Eco Alert
        </h1>

        {/* Navigation Buttons */}
        <nav className="flex space-x-10 text-2xl font-semibold mt-12">
          <a
            href="/resources"
            className="px-8 py-4 bg-white text-green-700 rounded-2xl shadow-lg hover:bg-green-100 transition duration-200"
          >
            Natural Resources
          </a>
          <a
            href="/about"
            className="px-8 py-4 bg-white text-green-700 rounded-2xl shadow-lg hover:bg-green-100 transition duration-200"
          >
            About
          </a>
          <a
            href="/contact"
            className="px-8 py-4 bg-white text-green-700 rounded-2xl shadow-lg hover:bg-green-100 transition duration-200"
          >
            Contact
          </a>
        </nav>
      </div>

      {/* Right Side: Three Vertical Templates */}
      <div className="flex-1 flex flex-col justify-center gap-12 p-8 overflow-y-auto">
        {/* Soil Erosion */}
        <div className="bg-white text-green-800 rounded-3xl p-8 shadow-2xl hover:scale-105 transition transform duration-300 cursor-pointer flex-1 flex items-center gap-6">
          <div className="flex-1 flex flex-col justify-center">
            <h2 className="text-5xl font-extrabold mb-6">Soil Erosion</h2>
            <p className="text-gray-700 text-lg leading-relaxed">
              Soil erosion is the gradual removal of fertile topsoil by water, wind, and human activities. This reduces soil fertility, disrupts ecosystems, and threatens agricultural productivity. Practices like deforestation, overgrazing, and improper farming accelerate erosion. Sustainable agriculture, reforestation, and terracing help preserve soil for future generations.
            </p>
          </div>
          <div className="flex-1 flex justify-center items-center">
            <img
              src="/images/soil-erosion.jpg"
              alt="Soil Erosion"
              className="w-full h-64 object-cover rounded-xl"
            />
          </div>
        </div>

        {/* Landslides */}
        <div className="bg-white text-green-800 rounded-3xl p-8 shadow-2xl hover:scale-105 transition transform duration-300 cursor-pointer flex-1 flex items-center gap-6">
          <div className="flex-1 flex flex-col justify-center">
            <h2 className="text-5xl font-extrabold mb-6">Landslides</h2>
            <p className="text-gray-700 text-lg leading-relaxed">
              Landslides happen when soil, rocks, and debris slide down slopes due to heavy rain, earthquakes, or deforestation. They can destroy homes, roads, and habitats. Proper slope management, planting vegetation, and avoiding construction on unstable land are essential strategies to mitigate risks and protect communities.
            </p>
          </div>
          <div className="flex-1 flex justify-center items-center">
            <img
              src="/images/landslide.jpg"
              alt="Landslide"
              className="w-full h-64 object-cover rounded-xl"
            />
          </div>
        </div>

        {/* Desertification */}
        <div className="bg-white text-green-800 rounded-3xl p-8 shadow-2xl hover:scale-105 transition transform duration-300 cursor-pointer flex-1 flex items-center gap-6">
          <div className="flex-1 flex flex-col justify-center">
            <h2 className="text-5xl font-extrabold mb-6">Desertification</h2>
            <p className="text-gray-700 text-lg leading-relaxed">
              Desertification is the degradation of fertile land into desert due to overuse, deforestation, and climate change. It reduces agricultural yields, food security, and biodiversity. Combating it requires sustainable land management, reforestation, efficient irrigation, and community-driven initiatives to restore soil health and prevent desert spread.
            </p>
          </div>
          <div className="flex-1 flex justify-center items-center">
            <img
              src="/images/desertification.jpg"
              alt="Desertification"
              className="w-full h-64 object-cover rounded-xl"
            />
          </div>
        </div>
      </div>
    </div>
  );
}
