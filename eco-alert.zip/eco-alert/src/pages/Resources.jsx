import { Link } from "react-router-dom";

function Resources() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-green-100 via-green-200 to-green-300 p-10">
      {/* Page Title */}
      <h1 className="text-6xl font-extrabold text-green-900 mb-12 text-center drop-shadow-lg">
        🌿 Natural Resources
      </h1>

      {/* ========== SOIL EROSION TEMPLATE ========== */}
      <section className="bg-gradient-to-r from-green-100 via-green-200 to-green-300 rounded-3xl shadow-2xl p-10 mb-20">
        <h2 className="text-5xl font-bold text-green-900 mb-8">🌱 Soil Erosion</h2>
        <div className="grid grid-cols-2 gap-10 items-start">
          {/* Image */}
          <img
            src="/images/pic1.jpg"
            alt="Soil Erosion"
            className="rounded-3xl shadow-xl object-cover w-full h-[500px]"
          />
          {/* 2x2 Grid */}
          <div className="grid grid-cols-2 grid-rows-2 gap-6 h-[500px]">
            <div className="bg-white rounded-2xl shadow-lg p-6 hover:scale-105 transition">
              <h3 className="text-2xl font-bold text-green-800 mb-2">📖 Definition</h3>
              <p className="text-md text-gray-700 leading-relaxed">
                Soil erosion is the gradual wearing away of the topsoil layer
                caused by water, wind, or human activities.
              </p>
            </div>
            <div className="bg-white rounded-2xl shadow-lg p-6 hover:scale-105 transition">
              <h3 className="text-2xl font-bold text-green-800 mb-2">⚠️ Causes</h3>
              <p className="text-md text-gray-700 leading-relaxed">
                Deforestation, overgrazing, intensive farming, and heavy rainfall
                contribute to soil erosion.
              </p>
            </div>
            <div className="bg-white rounded-2xl shadow-lg p-6 hover:scale-105 transition">
              <h3 className="text-2xl font-bold text-green-800 mb-2">🌍 Impacts</h3>
              <p className="text-md text-gray-700 leading-relaxed">
                Loss of fertile soil, reduced crop productivity, and increased
                vulnerability to floods.
              </p>
            </div>
            <div className="bg-white rounded-2xl shadow-lg p-6 hover:scale-105 transition">
              <h3 className="text-2xl font-bold text-green-800 mb-2">🛡️ Prevention</h3>
              <p className="text-md text-gray-700 leading-relaxed">
                Planting cover crops, building terraces, and practicing
                sustainable farming techniques.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* ========== LANDSLIDES TEMPLATE ========== */}
      <section className="bg-gradient-to-r from-green-100 via-green-200 to-green-300 rounded-3xl shadow-2xl p-10 mb-20">
        <h2 className="text-5xl font-bold text-green-900 mb-8">⛰️ Landslides</h2>
        <div className="grid grid-cols-2 gap-10 items-start">
          {/* Image */}
          <img
            src="/images/pic2.jpg"
            alt="Landslides"
            className="rounded-3xl shadow-xl object-cover w-full h-[500px]"
          />
          {/* 2x2 Grid */}
          <div className="grid grid-cols-2 grid-rows-2 gap-6 h-[500px]">
            <div className="bg-white rounded-2xl shadow-lg p-6 hover:scale-105 transition">
              <h3 className="text-2xl font-bold text-green-800 mb-2">📖 Definition</h3>
              <p className="text-md text-gray-700 leading-relaxed">
                Landslides are the downward movement of rocks, soil, and debris
                due to gravity, often triggered by rainfall or earthquakes.
              </p>
            </div>
            <div className="bg-white rounded-2xl shadow-lg p-6 hover:scale-105 transition">
              <h3 className="text-2xl font-bold text-green-800 mb-2">⚠️ Causes</h3>
              <p className="text-md text-gray-700 leading-relaxed">
                Heavy rainfall, deforestation, earthquakes, and mining activities
                destabilize slopes and cause landslides.
              </p>
            </div>
            <div className="bg-white rounded-2xl shadow-lg p-6 hover:scale-105 transition">
              <h3 className="text-2xl font-bold text-green-800 mb-2">🌍 Impacts</h3>
              <p className="text-md text-gray-700 leading-relaxed">
                Loss of lives, destruction of infrastructure, blocked rivers, and
                long-term land degradation.
              </p>
            </div>
            <div className="bg-white rounded-2xl shadow-lg p-6 hover:scale-105 transition">
              <h3 className="text-2xl font-bold text-green-800 mb-2">🛡️ Prevention</h3>
              <p className="text-md text-gray-700 leading-relaxed">
                Afforestation, slope stabilization, proper drainage systems, and
                early warning technologies.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* ========== DESERTIFICATION TEMPLATE ========== */}
      <section className="bg-gradient-to-r from-green-100 via-green-200 to-green-300 rounded-3xl shadow-2xl p-10 mb-20">
        <h2 className="text-5xl font-bold text-green-900 mb-8">🏜️ Desertification</h2>
        <div className="grid grid-cols-2 gap-10 items-start">
          {/* Image */}
          <img
            src="/images/pic3.jpg"
            alt="Desertification"
            className="rounded-3xl shadow-xl object-cover w-full h-[500px]"
          />
          {/* 2x2 Grid */}
          <div className="grid grid-cols-2 grid-rows-2 gap-6 h-[500px]">
            <div className="bg-white rounded-2xl shadow-lg p-6 hover:scale-105 transition">
              <h3 className="text-2xl font-bold text-green-800 mb-2">📖 Definition</h3>
              <p className="text-md text-gray-700 leading-relaxed">
                Desertification is the transformation of fertile land into desert
                due to climate change and unsustainable land use.
              </p>
            </div>
            <div className="bg-white rounded-2xl shadow-lg p-6 hover:scale-105 transition">
              <h3 className="text-2xl font-bold text-green-800 mb-2">⚠️ Causes</h3>
              <p className="text-md text-gray-700 leading-relaxed">
                Overgrazing, deforestation, excessive farming, and prolonged
                droughts drive desertification.
              </p>
            </div>
            <div className="bg-white rounded-2xl shadow-lg p-6 hover:scale-105 transition">
              <h3 className="text-2xl font-bold text-green-800 mb-2">🌍 Impacts</h3>
              <p className="text-md text-gray-700 leading-relaxed">
                Food insecurity, displacement of communities, loss of biodiversity,
                and reduced water availability.
              </p>
            </div>
            <div className="bg-white rounded-2xl shadow-lg p-6 hover:scale-105 transition">
              <h3 className="text-2xl font-bold text-green-800 mb-2">🛡️ Prevention</h3>
              <p className="text-md text-gray-700 leading-relaxed">
                Sustainable farming, water conservation, reforestation, and
                climate change adaptation strategies.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Back Button */}
      <Link to="/">
        <button className="mt-12 px-8 py-4 bg-green-700 text-white rounded-2xl font-bold text-xl shadow-lg hover:bg-green-800 transition block mx-auto">
          ⬅ Back to Home
        </button>
      </Link>
    </div>
  );
}

export default Resources;
