import { Link } from "react-router-dom";

function About() {
  return (
    <div className="w-full min-h-screen bg-gradient-to-br from-green-200 via-green-300 to-lime-200 flex">

      {/* Left Side: Templates */}
      <div className="flex-1 flex flex-col gap-16 px-8 py-16">

        {/* Template 1: Interactive Learning */}
        <div className="bg-white text-green-800 rounded-3xl p-8 shadow-2xl hover:scale-105 transition transform duration-300 flex flex-col md:flex-row items-center gap-6">
          <div className="md:flex-1 flex justify-center items-center">
            <img
              src="/images/pic1.jpg"
              alt="Interactive Learning"
              className="w-full h-64 md:h-80 object-cover rounded-xl"
            />
          </div>
          <div className="md:flex-1 flex flex-col justify-center md:pl-6">
            <h2 className="text-5xl font-extrabold mb-6">Interactive Learning</h2>
            <p className="text-gray-700 text-lg leading-relaxed">
              Explore soil erosion, landslides, and desertification through interactive visuals, videos, and quizzes.
            </p>
          </div>
        </div>

        {/* Template 2: Community Engagement */}
        <div className="bg-white text-green-800 rounded-3xl p-8 shadow-2xl hover:scale-105 transition transform duration-300 flex flex-col md:flex-row items-center gap-6">
          <div className="md:flex-1 flex justify-center items-center">
            <img
              src="/images/pic2.jpg"
              alt="Community Engagement"
              className="w-full h-64 md:h-80 object-cover rounded-xl"
            />
          </div>
          <div className="md:flex-1 flex flex-col justify-center md:pl-6">
            <h2 className="text-5xl font-extrabold mb-6">Community Engagement</h2>
            <p className="text-gray-700 text-lg leading-relaxed">
              Connect with eco-conscious individuals, share insights, and collaborate to protect our environment.
            </p>
          </div>
        </div>

        {/* Template 3: Environmental Challenges Tracker */}
        <div className="bg-white text-green-800 rounded-3xl p-8 shadow-2xl hover:scale-105 transition transform duration-300 flex flex-col md:flex-row items-center gap-6">
          <div className="md:flex-1 flex justify-center items-center">
            <img
              src="/images/pic3.jpg"
              alt="Environmental Challenges Tracker"
              className="w-full h-64 md:h-80 object-cover rounded-xl"
            />
          </div>
          <div className="md:flex-1 flex flex-col justify-center md:pl-6">
            <h2 className="text-5xl font-extrabold mb-6">Environmental Challenges Tracker</h2>
            <p className="text-gray-700 text-lg leading-relaxed">
              Track soil erosion, landslide-prone areas, and desertification trends in your region. 
              Eco Alert helps you visualize and understand environmental risks for better awareness.
            </p>
          </div>
        </div>

        {/* Template 4: Sustainability Tips */}
        <div className="bg-white text-green-800 rounded-3xl p-8 shadow-2xl hover:scale-105 transition transform duration-300 flex flex-col md:flex-row items-center gap-6">
          <div className="md:flex-1 flex justify-center items-center">
            <img
              src="/images/pic4.jpg"
              alt="Sustainability Tips"
              className="w-full h-64 md:h-80 object-cover rounded-xl"
            />
          </div>
          <div className="md:flex-1 flex flex-col justify-center md:pl-6">
            <h2 className="text-5xl font-extrabold mb-6">Sustainability Tips</h2>
            <p className="text-gray-700 text-lg leading-relaxed">
              Learn eco-friendly habits and practical steps to reduce environmental impact in daily life.
            </p>
          </div>
        </div>

        {/* Template 5: Data & Insights */}
        <div className="bg-white text-green-800 rounded-3xl p-8 shadow-2xl hover:scale-105 transition transform duration-300 flex flex-col md:flex-row items-center gap-6">
          <div className="md:flex-1 flex justify-center items-center">
            <img
              src="/images/pic5.jpg"
              alt="Data & Insights"
              className="w-full h-64 md:h-80 object-cover rounded-xl"
            />
          </div>
          <div className="md:flex-1 flex flex-col justify-center md:pl-6">
            <h2 className="text-5xl font-extrabold mb-6">Data & Insights</h2>
            <p className="text-gray-700 text-lg leading-relaxed">
              Visual data and statistics help you understand environmental challenges and take informed action.
            </p>
          </div>
        </div>

      </div>

      {/* Right Side: Logo, Slogan, Page Title, Back Button */}
      <div className="w-1/2 flex flex-col justify-center items-center text-center px-8 py-16 sticky top-0 h-screen">

        {/* Slogan */}
        <p className="text-4xl md:text-5xl font-extrabold tracking-wider mb-6 drop-shadow-lg text-yellow-100">
          🌿 Explore. Learn. Act. Protect Our Planet! 🌱
        </p>

        {/* Logo */}
        <img
          src="/logo.png"
          alt="Eco Alert Logo"
          className="w-[28rem] h-[28rem] drop-shadow-2xl animate-bounce-slow object-contain mb-4"
        />

        {/* Page Title */}
        <h1 className="text-[6rem] md:text-[7rem] font-extrabold text-green-900 drop-shadow-md -mt-8">
          About Eco Alert
        </h1>

        {/* Back Button */}
        <Link to="/">
          <button className="mt-12 px-10 py-5 bg-green-700 text-white rounded-3xl font-bold shadow-lg hover:bg-green-800 hover:scale-105 transition transform duration-200">
            ⬅ Back to Home
          </button>
        </Link>
      </div>

    </div>
  );
}

export default About;
