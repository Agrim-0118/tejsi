import { Link } from "react-router-dom";

function Contact() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-purple-200 p-10">
      <h1 className="text-4xl font-bold text-purple-800 mb-6">Contact Us</h1>
      <form className="max-w-lg space-y-4">
        <input
          type="text"
          placeholder="Your Name"
          className="w-full p-3 rounded-lg border border-gray-300"
        />
        <input
          type="email"
          placeholder="Your Email"
          className="w-full p-3 rounded-lg border border-gray-300"
        />
        <textarea
          placeholder="Your Message"
          className="w-full p-3 rounded-lg border border-gray-300"
          rows="4"
        ></textarea>
        <button
          type="submit"
          className="px-6 py-3 bg-purple-600 text-white rounded-xl font-semibold hover:bg-purple-700 transition"
        >
          Send Message
        </button>
      </form>

      <Link to="/">
        <button className="mt-8 px-6 py-3 bg-gray-600 text-white rounded-xl font-semibold hover:bg-gray-700 transition">
          ⬅ Back to Home
        </button>
      </Link>
    </div>
  );
}

export default Contact;
